// Backend API for All Resizer application
// This file handles server-side functionality like saving and retrieving images

const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const cors = require('cors');

// Create express app
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, '/'))); // Serve static files

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// In-memory database (for demo purposes)
// In a real app, you would use a proper database like MongoDB or PostgreSQL
let images = [];
let editHistory = [];

// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    cb(null, uuidv4() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// API Routes

// Get all images
app.get('/api/images', (req, res) => {
  res.json(images);
});

// Get a specific image
app.get('/api/images/:id', (req, res) => {
  const image = images.find(img => img.id === req.params.id);
  if (!image) {
    return res.status(404).json({ error: 'Image not found' });
  }
  res.json(image);
});

// Save an image
app.post('/api/save-image', (req, res) => {
  try {
    const { name, dataUrl, format, width, height, adjustments } = req.body;
    
    // Generate unique ID
    const id = uuidv4();
    
    // Extract the base64 data
    const base64Data = dataUrl.replace(/^data:image\/\w+;base64,/, '');
    
    // Create filename
    const filename = `${id}.${format}`;
    const filepath = path.join(uploadsDir, filename);
    
    // Save the file
    fs.writeFileSync(filepath, base64Data, { encoding: 'base64' });
    
    // Create image record
    const newImage = {
      id,
      name,
      url: `/uploads/${filename}`,
      format,
      width,
      height,
      adjustments,
      createdAt: new Date().toISOString()
    };
    
    // Add to our "database"
    images.push(newImage);
    
    res.status(201).json(newImage);
  } catch (error) {
    console.error('Error saving image:', error);
    res.status(500).json({ error: 'Failed to save image' });
  }
});

// Update an image
app.put('/api/images/:id', (req, res) => {
  const imageId = req.params.id;
  const imageIndex = images.findIndex(img => img.id === imageId);
  
  if (imageIndex === -1) {
    return res.status(404).json({ error: 'Image not found' });
  }
  
  // Update image data
  const { name, adjustments } = req.body;
  
  if (name) {
    images[imageIndex].name = name;
  }
  
  if (adjustments) {
    images[imageIndex].adjustments = adjustments;
  }
  
  res.json(images[imageIndex]);
});

// Delete an image
app.delete('/api/images/:id', (req, res) => {
  const imageId = req.params.id;
  const imageIndex = images.findIndex(img => img.id === imageId);
  
  if (imageIndex === -1) {
    return res.status(404).json({ error: 'Image not found' });
  }
  
  // Delete the file
  try {
    const filePath = path.join(__dirname, images[imageIndex].url);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (error) {
    console.error('Error deleting file:', error);
  }
  
  // Remove from database
  images.splice(imageIndex, 1);
  
  res.status(204).send();
});

// Get edit history for an image
app.get('/api/images/:id/history', (req, res) => {
  const imageId = req.params.id;
  const history = editHistory.filter(h => h.imageId === imageId);
  res.json(history);
});

// Add edit history entry for an image
app.post('/api/images/:id/history', (req, res) => {
  const imageId = req.params.id;
  const { adjustments } = req.body;
  
  // Check if image exists
  const image = images.find(img => img.id === imageId);
  if (!image) {
    return res.status(404).json({ error: 'Image not found' });
  }
  
  // Create history entry
  const historyEntry = {
    id: uuidv4(),
    imageId,
    adjustments,
    createdAt: new Date().toISOString()
  };
  
  // Add to history
  editHistory.push(historyEntry);
  
  res.status(201).json(historyEntry);
});

// Serve the main HTML file for all other routes (for SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
  console.log(`Access All Resizer at http://localhost:${port}`);
});