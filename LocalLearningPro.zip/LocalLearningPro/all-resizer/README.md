# All Resizer - Image Editing Tool

All Resizer is a free, professional image editing application that allows users to resize, crop, adjust, and enhance their images directly in the browser. This repository contains both frontend and backend code for the application.

## Features

- **Image Transformations**: Resize, rotate, and flip images
- **Background Removal**: Simple background removal tool
- **Color Adjustments**: Modify brightness, contrast, and saturation
- **Format Conversion**: Convert between JPG, PNG, and WEBP formats
- **Save & Download**: Save images to the server or download them directly
- **Edit History**: Undo and redo changes

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository or download the files

2. Install the dependencies:
   ```
   npm install
   ```

3. Start the server:
   ```
   npm start
   ```

4. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

## Deployment to Netlify

For deploying the static frontend version without the backend functionality:

1. Create a new site on Netlify
2. Upload the following files:
   - index.html
   - styles.css
   - frontend.js

Or connect your GitHub repository to Netlify for automatic deployments.

## Full-stack Deployment

For deploying the full application with backend functionality:

1. Deploy the backend to a service like Heroku, Render, or DigitalOcean:
   ```
   git push heroku main
   ```

2. Make sure to set up the proper environment variables for your deployment platform.

## Project Structure

- `index.html` - Main HTML file with the user interface
- `styles.css` - CSS styles for the application
- `frontend.js` - Frontend JavaScript code for image processing
- `backend.js` - Backend API for saving and retrieving images
- `package.json` - Node.js dependencies and scripts
- `uploads/` - Directory for storing uploaded images (created automatically)

## Technologies Used

- HTML, CSS, JavaScript (Frontend)
- Express.js (Backend)
- Canvas API for image processing
- Multer for file uploads
- UUID for generating unique IDs

## License

This project is licensed under the MIT License - see the LICENSE file for details.