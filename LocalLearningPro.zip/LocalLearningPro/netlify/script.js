// DOM Elements
const app = document.getElementById('app');
const themeToggle = document.getElementById('theme-toggle');
const moonIcon = document.getElementById('moon-icon');
const sunIcon = document.getElementById('sun-icon');
const comparisonSlider = document.getElementById('comparison-slider');
const comparisonBefore = document.getElementById('comparison-before');
const comparisonHandle = document.getElementById('comparison-handle');
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('file-input');
const uploadArea = document.getElementById('upload-area');
const editorWorkspace = document.getElementById('editor-workspace');
const widthInput = document.getElementById('width-input');
const heightInput = document.getElementById('height-input');
const aspectRatioCheckbox = document.getElementById('aspect-ratio-checkbox');
const rotateBtn = document.getElementById('rotate-btn');
const flipHBtn = document.getElementById('flip-h-btn');
const flipVBtn = document.getElementById('flip-v-btn');
const removeBgBtn = document.getElementById('remove-bg-btn');
const brightnessSlider = document.getElementById('brightness-slider');
const brightnessValue = document.getElementById('brightness-value');
const contrastSlider = document.getElementById('contrast-slider');
const contrastValue = document.getElementById('contrast-value');
const saturationSlider = document.getElementById('saturation-slider');
const saturationValue = document.getElementById('saturation-value');
const formatSelect = document.getElementById('format-select');
const qualitySlider = document.getElementById('quality-slider');
const downloadBtn = document.getElementById('download-btn');
const previewImage = document.getElementById('preview-image');
const previewPlaceholder = document.getElementById('preview-placeholder');
const loadingOverlay = document.getElementById('loading-overlay');
const undoBtn = document.getElementById('undo-btn');
const redoBtn = document.getElementById('redo-btn');
const resetBtn = document.getElementById('reset-btn');
const currentYearEl = document.getElementById('current-year');

// State
let originalImage = null;
let editHistory = [];
let historyIndex = -1;
let currentAdjustments = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  width: null,
  height: null,
  rotate: 0,
  flipH: false,
  flipV: false
};

// Theme Toggle
function initTheme() {
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.classList.toggle('dark', savedTheme === 'dark');
  updateThemeIcons(savedTheme);
}

function updateThemeIcons(theme) {
  if (theme === 'dark') {
    moonIcon.classList.add('hidden');
    sunIcon.classList.remove('hidden');
  } else {
    sunIcon.classList.add('hidden');
    moonIcon.classList.remove('hidden');
  }
}

function toggleTheme() {
  const isDark = document.documentElement.classList.toggle('dark');
  const newTheme = isDark ? 'dark' : 'light';
  localStorage.setItem('theme', newTheme);
  updateThemeIcons(newTheme);
}

// Comparison Slider
function initComparisonSlider() {
  let isDragging = false;
  
  comparisonHandle.addEventListener('mousedown', () => {
    isDragging = true;
  });
  
  comparisonSlider.addEventListener('mouseup', () => {
    isDragging = false;
  });
  
  comparisonSlider.addEventListener('mouseleave', () => {
    isDragging = false;
  });
  
  comparisonSlider.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    
    const sliderRect = comparisonSlider.getBoundingClientRect();
    const position = (e.clientX - sliderRect.left) / sliderRect.width;
    const percentage = Math.max(0, Math.min(1, position)) * 100;
    
    comparisonBefore.style.width = `${percentage}%`;
    comparisonHandle.style.left = `${percentage}%`;
  });
  
  // Touch support
  comparisonHandle.addEventListener('touchstart', () => {
    isDragging = true;
  });
  
  comparisonSlider.addEventListener('touchend', () => {
    isDragging = false;
  });
  
  comparisonSlider.addEventListener('touchcancel', () => {
    isDragging = false;
  });
  
  comparisonSlider.addEventListener('touchmove', (e) => {
    if (!isDragging) return;
    e.preventDefault();
    
    const touch = e.touches[0];
    const sliderRect = comparisonSlider.getBoundingClientRect();
    const position = (touch.clientX - sliderRect.left) / sliderRect.width;
    const percentage = Math.max(0, Math.min(1, position)) * 100;
    
    comparisonBefore.style.width = `${percentage}%`;
    comparisonHandle.style.left = `${percentage}%`;
  });
}

// Accordion functionality
function initAccordions() {
  const accordions = document.querySelectorAll('.accordion');
  
  accordions.forEach((accordion, index) => {
    const header = accordion.querySelector('.accordion-header');
    const content = accordion.querySelector('.accordion-content');
    
    // Open the first accordion by default
    if (index === 0) {
      accordion.classList.add('active');
      content.style.maxHeight = content.scrollHeight + 'px';
    }
    
    header.addEventListener('click', () => {
      accordion.classList.toggle('active');
      
      if (accordion.classList.contains('active')) {
        content.style.maxHeight = content.scrollHeight + 'px';
      } else {
        content.style.maxHeight = '0';
      }
    });
  });
}

// File Upload
function initFileUpload() {
  // Click to browse
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      handleFileUpload(file);
    }
  });
  
  // Drag and drop
  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('active');
  });
  
  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('active');
  });
  
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('active');
    
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileUpload(file);
    }
  });
}

function handleFileUpload(file) {
  // Check if it's an image
  if (!file.type.match('image.*')) {
    alert('Please upload an image file.');
    return;
  }
  
  const reader = new FileReader();
  
  reader.onload = (e) => {
    // Create an image element to get dimensions
    const img = new Image();
    img.onload = () => {
      // Save the original image for processing
      originalImage = img;
      
      // Set initial width and height inputs
      widthInput.value = img.width;
      heightInput.value = img.height;
      
      // Update current adjustments
      currentAdjustments.width = img.width;
      currentAdjustments.height = img.height;
      
      // Switch from upload to editor
      uploadArea.classList.add('hidden');
      editorWorkspace.classList.remove('hidden');
      
      // Set the preview
      previewImage.src = e.target.result;
      previewImage.classList.remove('hidden');
      previewPlaceholder.classList.add('hidden');
      
      // Enable reset button
      resetBtn.disabled = false;
      
      // Save to history
      addToHistory();
    };
    
    img.src = e.target.result;
  };
  
  reader.readAsDataURL(file);
}

// Resize functionality
function initResizeInputs() {
  let aspectRatio = null;
  
  // Calculate aspect ratio when image is loaded
  widthInput.addEventListener('focus', () => {
    if (originalImage && aspectRatioCheckbox.checked) {
      aspectRatio = originalImage.width / originalImage.height;
    }
  });
  
  heightInput.addEventListener('focus', () => {
    if (originalImage && aspectRatioCheckbox.checked) {
      aspectRatio = originalImage.width / originalImage.height;
    }
  });
  
  // Width change
  widthInput.addEventListener('input', () => {
    if (!originalImage) return;
    
    const newWidth = parseInt(widthInput.value) || originalImage.width;
    currentAdjustments.width = newWidth;
    
    if (aspectRatioCheckbox.checked && aspectRatio) {
      const newHeight = Math.round(newWidth / aspectRatio);
      heightInput.value = newHeight;
      currentAdjustments.height = newHeight;
    }
    
    processImage();
  });
  
  // Height change
  heightInput.addEventListener('input', () => {
    if (!originalImage) return;
    
    const newHeight = parseInt(heightInput.value) || originalImage.height;
    currentAdjustments.height = newHeight;
    
    if (aspectRatioCheckbox.checked && aspectRatio) {
      const newWidth = Math.round(newHeight * aspectRatio);
      widthInput.value = newWidth;
      currentAdjustments.width = newWidth;
    }
    
    processImage();
  });
  
  // Aspect ratio toggle
  aspectRatioCheckbox.addEventListener('change', () => {
    if (originalImage && aspectRatioCheckbox.checked) {
      aspectRatio = originalImage.width / originalImage.height;
      
      // Adjust height based on current width
      const newWidth = parseInt(widthInput.value) || originalImage.width;
      const newHeight = Math.round(newWidth / aspectRatio);
      heightInput.value = newHeight;
      currentAdjustments.height = newHeight;
      
      processImage();
    }
  });
}

// Rotate and flip
function initTransformButtons() {
  rotateBtn.addEventListener('click', () => {
    if (!originalImage) return;
    
    currentAdjustments.rotate = (currentAdjustments.rotate + 90) % 360;
    
    // Swap width and height if rotating by 90 or 270 degrees
    if (currentAdjustments.rotate === 90 || currentAdjustments.rotate === 270) {
      const temp = currentAdjustments.width;
      currentAdjustments.width = currentAdjustments.height;
      currentAdjustments.height = temp;
      
      widthInput.value = currentAdjustments.width;
      heightInput.value = currentAdjustments.height;
    }
    
    processImage();
    addToHistory();
  });
  
  flipHBtn.addEventListener('click', () => {
    if (!originalImage) return;
    
    currentAdjustments.flipH = !currentAdjustments.flipH;
    processImage();
    addToHistory();
  });
  
  flipVBtn.addEventListener('click', () => {
    if (!originalImage) return;
    
    currentAdjustments.flipV = !currentAdjustments.flipV;
    processImage();
    addToHistory();
  });
}

// Background removal (simplified for demo - in a real app, this would use ML)
function initBackgroundRemoval() {
  removeBgBtn.addEventListener('click', () => {
    if (!originalImage) return;
    
    showLoading(true);
    
    // This is a simplified version - it just creates a basic circle mask
    // In a real app, you'd use a proper ML model for background removal
    setTimeout(() => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      canvas.width = currentAdjustments.width;
      canvas.height = currentAdjustments.height;
      
      // Draw a circle in the center
      ctx.save();
      ctx.beginPath();
      const radius = Math.min(canvas.width, canvas.height) * 0.4;
      ctx.arc(canvas.width / 2, canvas.height / 2, radius, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      
      // Draw the image
      applyTransforms(ctx, canvas.width, canvas.height);
      ctx.drawImage(
        originalImage,
        0, 0, originalImage.width, originalImage.height,
        0, 0, canvas.width, canvas.height
      );
      ctx.restore();
      
      // Update preview
      previewImage.src = canvas.toDataURL();
      showLoading(false);
      
      addToHistory();
    }, 1500); // Simulated processing delay
  });
}

// Adjustment sliders
function initAdjustmentSliders() {
  // Brightness
  brightnessSlider.addEventListener('input', () => {
    currentAdjustments.brightness = parseInt(brightnessSlider.value);
    brightnessValue.textContent = brightnessSlider.value;
    processImage();
  });
  
  brightnessSlider.addEventListener('change', () => {
    addToHistory();
  });
  
  // Contrast
  contrastSlider.addEventListener('input', () => {
    currentAdjustments.contrast = parseInt(contrastSlider.value);
    contrastValue.textContent = contrastSlider.value;
    processImage();
  });
  
  contrastSlider.addEventListener('change', () => {
    addToHistory();
  });
  
  // Saturation
  saturationSlider.addEventListener('input', () => {
    currentAdjustments.saturation = parseInt(saturationSlider.value);
    saturationValue.textContent = saturationSlider.value;
    processImage();
  });
  
  saturationSlider.addEventListener('change', () => {
    addToHistory();
  });
}

// Export options
function initExportOptions() {
  downloadBtn.addEventListener('click', () => {
    if (!originalImage) return;
    
    const format = formatSelect.value;
    const quality = parseInt(qualitySlider.value) / 100;
    
    // Create a canvas with current adjustments
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    canvas.width = currentAdjustments.width;
    canvas.height = currentAdjustments.height;
    
    // Apply transformations and draw
    applyTransforms(ctx, canvas.width, canvas.height);
    ctx.drawImage(
      originalImage,
      0, 0, originalImage.width, originalImage.height,
      0, 0, canvas.width, canvas.height
    );
    
    // Apply adjustments
    applyAdjustments(ctx, canvas.width, canvas.height);
    
    // Convert to desired format
    let mimeType = 'image/jpeg';
    if (format === 'png') {
      mimeType = 'image/png';
    } else if (format === 'webp') {
      mimeType = 'image/webp';
    }
    
    // Create download link
    const dataUrl = canvas.toDataURL(mimeType, quality);
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `edited-image.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });
}

// History management
function initHistoryButtons() {
  undoBtn.addEventListener('click', () => {
    if (historyIndex > 0) {
      historyIndex--;
      loadFromHistory();
      updateHistoryButtons();
    }
  });
  
  redoBtn.addEventListener('click', () => {
    if (historyIndex < editHistory.length - 1) {
      historyIndex++;
      loadFromHistory();
      updateHistoryButtons();
    }
  });
  
  resetBtn.addEventListener('click', () => {
    if (!originalImage) return;
    
    // Reset all adjustments
    currentAdjustments = {
      brightness: 0,
      contrast: 0,
      saturation: 0,
      width: originalImage.width,
      height: originalImage.height,
      rotate: 0,
      flipH: false,
      flipV: false
    };
    
    // Reset UI
    brightnessSlider.value = 0;
    brightnessValue.textContent = '0';
    contrastSlider.value = 0;
    contrastValue.textContent = '0';
    saturationSlider.value = 0;
    saturationValue.textContent = '0';
    widthInput.value = originalImage.width;
    heightInput.value = originalImage.height;
    
    // Process image with reset values
    processImage();
    
    // Add to history
    addToHistory();
  });
}

function addToHistory() {
  // If we're not at the end of history, remove future states
  if (historyIndex < editHistory.length - 1) {
    editHistory = editHistory.slice(0, historyIndex + 1);
  }
  
  // Add current state to history
  editHistory.push({ ...currentAdjustments });
  historyIndex = editHistory.length - 1;
  
  // Update history buttons
  updateHistoryButtons();
}

function loadFromHistory() {
  if (historyIndex >= 0 && historyIndex < editHistory.length) {
    // Load adjustments from history
    currentAdjustments = { ...editHistory[historyIndex] };
    
    // Update UI
    brightnessSlider.value = currentAdjustments.brightness;
    brightnessValue.textContent = currentAdjustments.brightness;
    contrastSlider.value = currentAdjustments.contrast;
    contrastValue.textContent = currentAdjustments.contrast;
    saturationSlider.value = currentAdjustments.saturation;
    saturationValue.textContent = currentAdjustments.saturation;
    widthInput.value = currentAdjustments.width;
    heightInput.value = currentAdjustments.height;
    
    // Process image
    processImage();
  }
}

function updateHistoryButtons() {
  undoBtn.disabled = historyIndex <= 0;
  redoBtn.disabled = historyIndex >= editHistory.length - 1;
}

// Image processing
function processImage() {
  if (!originalImage) return;
  
  showLoading(true);
  
  // Use setTimeout to allow the loading overlay to appear
  setTimeout(() => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    canvas.width = currentAdjustments.width;
    canvas.height = currentAdjustments.height;
    
    // Apply transformations and draw
    applyTransforms(ctx, canvas.width, canvas.height);
    ctx.drawImage(
      originalImage,
      0, 0, originalImage.width, originalImage.height,
      0, 0, canvas.width, canvas.height
    );
    
    // Apply adjustments
    applyAdjustments(ctx, canvas.width, canvas.height);
    
    // Update preview
    previewImage.src = canvas.toDataURL();
    showLoading(false);
  }, 0);
}

function applyTransforms(ctx, width, height) {
  // Apply rotation
  if (currentAdjustments.rotate !== 0) {
    ctx.translate(width / 2, height / 2);
    ctx.rotate((currentAdjustments.rotate * Math.PI) / 180);
    ctx.translate(-width / 2, -height / 2);
  }
  
  // Apply flips
  if (currentAdjustments.flipH) {
    ctx.translate(width, 0);
    ctx.scale(-1, 1);
  }
  
  if (currentAdjustments.flipV) {
    ctx.translate(0, height);
    ctx.scale(1, -1);
  }
}

function applyAdjustments(ctx, width, height) {
  // Get image data
  const imageData = ctx.getImageData(0, 0, width, height);
  const data = imageData.data;
  
  // Calculate adjustment values (normalized to 0-2 range)
  const brightness = 1 + currentAdjustments.brightness / 100;
  const contrast = 1 + currentAdjustments.contrast / 100;
  const saturation = 1 + currentAdjustments.saturation / 100;
  
  // Apply adjustments to each pixel
  for (let i = 0; i < data.length; i += 4) {
    // Skip fully transparent pixels
    if (data[i + 3] === 0) continue;
    
    // Apply brightness
    data[i] = clamp(data[i] * brightness);
    data[i + 1] = clamp(data[i + 1] * brightness);
    data[i + 2] = clamp(data[i + 2] * brightness);
    
    // Apply contrast
    data[i] = clamp(((data[i] / 255 - 0.5) * contrast + 0.5) * 255);
    data[i + 1] = clamp(((data[i + 1] / 255 - 0.5) * contrast + 0.5) * 255);
    data[i + 2] = clamp(((data[i + 2] / 255 - 0.5) * contrast + 0.5) * 255);
    
    // Apply saturation
    const gray = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
    data[i] = clamp(gray + (data[i] - gray) * saturation);
    data[i + 1] = clamp(gray + (data[i + 1] - gray) * saturation);
    data[i + 2] = clamp(gray + (data[i + 2] - gray) * saturation);
  }
  
  // Put the modified data back
  ctx.putImageData(imageData, 0, 0);
}

function clamp(value) {
  return Math.max(0, Math.min(255, value));
}

function showLoading(show) {
  if (show) {
    loadingOverlay.classList.remove('hidden');
  } else {
    loadingOverlay.classList.add('hidden');
  }
}

// Initialize everything
function init() {
  // Set current year in footer
  currentYearEl.textContent = new Date().getFullYear();
  
  // Initialize theme
  initTheme();
  themeToggle.addEventListener('click', toggleTheme);
  
  // Initialize comparison slider
  initComparisonSlider();
  
  // Initialize accordions
  initAccordions();
  
  // Initialize file upload
  initFileUpload();
  
  // Initialize image editing tools
  initResizeInputs();
  initTransformButtons();
  initBackgroundRemoval();
  initAdjustmentSliders();
  initExportOptions();
  initHistoryButtons();
}

// Run initialization when DOM is fully loaded
document.addEventListener('DOMContentLoaded', init);