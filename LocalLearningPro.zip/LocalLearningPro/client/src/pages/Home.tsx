import React from "react";
import Header from "@/components/Header";
import BeforeAfterSlider from "@/components/BeforeAfterSlider";
import ImageEditorWithDatabase from "@/components/ImageEditorWithDatabase";
import ToolCard from "@/components/ToolCard";
import ExampleCard from "@/components/ExampleCard";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";
import { 
  Image, 
  Crop, 
  Palette, 
  Copy, 
  EyeOff, 
  Edit 
} from "lucide-react";

export default function Home() {
  // Before/After comparison images
  const comparisonImages = {
    before: "https://images.unsplash.com/photo-1520262494112-9fe481d36ec3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600&sat=-30&con=-20",
    after: "https://images.unsplash.com/photo-1520262494112-9fe481d36ec3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600"
  };

  // Example images
  const examples = [
    {
      title: "Background Removal",
      beforeImage: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      afterImage: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      beforeAlt: "Product on background before editing",
      afterAlt: "Product with background removed"
    },
    {
      title: "Color Enhancement",
      beforeImage: "https://images.unsplash.com/photo-1589561253898-768105ca91a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&sat=-30&con=-20",
      afterImage: "https://images.unsplash.com/photo-1589561253898-768105ca91a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
      beforeAlt: "Photo before color enhancement",
      afterAlt: "Photo after color enhancement"
    }
  ];

  // Tool cards
  const tools = [
    {
      title: "Background Removal",
      description: "Easily remove backgrounds from your images with our AI-powered tool.",
      icon: EyeOff
    },
    {
      title: "Resize & Crop",
      description: "Perfectly resize and crop your images for any purpose.",
      icon: Crop
    },
    {
      title: "Color Adjustments",
      description: "Fine-tune brightness, contrast, saturation, and more.",
      icon: Palette
    },
    {
      title: "Format Conversion",
      description: "Convert between JPG, PNG, and WEBP formats.",
      icon: Copy
    },
    {
      title: "Image Compression",
      description: "Reduce file size while maintaining quality.",
      icon: Image
    },
    {
      title: "Basic Retouching",
      description: "Simple tools to enhance and retouch your photos.",
      icon: Edit
    }
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="container mx-auto px-4 py-8 md:px-12 lg:px-24">
        {/* Hero Section */}
        <section className="mb-16 animate-fade-in">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Professional Image Editing <span className="text-primary dark:text-primary">Made Simple</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
              Edit your images with our powerful yet easy-to-use tools. No sign-up required, 100% free.
            </p>
          </div>

          {/* Before/After Showcase */}
          <BeforeAfterSlider beforeImage={comparisonImages.before} afterImage={comparisonImages.after} />
        </section>

        {/* Image Editor Section */}
        <ImageEditorWithDatabase />

        {/* Tools Section */}
        <section id="tools" className="mb-16 animate-fade-in">
          <h2 className="text-3xl font-bold text-center mb-8">Powerful Editing Tools</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {tools.map((tool, index) => (
              <ToolCard 
                key={index}
                title={tool.title}
                description={tool.description}
                icon={tool.icon}
              />
            ))}
          </div>
        </section>

        {/* Examples Section */}
        <section id="examples" className="mb-16 animate-fade-in">
          <h2 className="text-3xl font-bold text-center mb-8">See What You Can Create</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {examples.map((example, index) => (
              <ExampleCard
                key={index}
                title={example.title}
                beforeImage={example.beforeImage}
                afterImage={example.afterImage}
                beforeAlt={example.beforeAlt}
                afterAlt={example.afterAlt}
              />
            ))}
          </div>
        </section>

        {/* FAQ Section */}
        <div id="faq">
          <FAQ />
        </div>
      </main>

      <Footer />
    </div>
  );
}
