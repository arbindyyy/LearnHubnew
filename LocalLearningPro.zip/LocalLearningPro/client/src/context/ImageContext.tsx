import { createContext, useContext, useState, ReactNode } from "react";

interface ImageAdjustments {
  brightness: number;
  contrast: number;
  saturation: number;
}

interface ImageSize {
  width: number;
  height: number;
  maintainAspectRatio: boolean;
}

interface ExportSettings {
  format: "jpg" | "png" | "webp";
  quality: number;
}

interface ImageContextType {
  originalImage: HTMLImageElement | null;
  setOriginalImage: (image: HTMLImageElement | null) => void;
  processedImage: string | null;
  setProcessedImage: (url: string | null) => void;
  isProcessing: boolean;
  setIsProcessing: (processing: boolean) => void;
  adjustments: ImageAdjustments;
  setAdjustments: (adjustments: ImageAdjustments) => void;
  size: ImageSize;
  setSize: (size: ImageSize) => void;
  exportSettings: ExportSettings;
  setExportSettings: (settings: ExportSettings) => void;
  resetAll: () => void;
}

const defaultAdjustments: ImageAdjustments = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
};

const defaultSize: ImageSize = {
  width: 800,
  height: 600,
  maintainAspectRatio: true,
};

const defaultExportSettings: ExportSettings = {
  format: "jpg",
  quality: 80,
};

const ImageContext = createContext<ImageContextType | undefined>(undefined);

export function ImageProvider({ children }: { children: ReactNode }) {
  const [originalImage, setOriginalImage] = useState<HTMLImageElement | null>(null);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [adjustments, setAdjustments] = useState<ImageAdjustments>(defaultAdjustments);
  const [size, setSize] = useState<ImageSize>(defaultSize);
  const [exportSettings, setExportSettings] = useState<ExportSettings>(defaultExportSettings);

  const resetAll = () => {
    setAdjustments(defaultAdjustments);
    setSize(defaultSize);
    setExportSettings(defaultExportSettings);
  };

  return (
    <ImageContext.Provider 
      value={{
        originalImage,
        setOriginalImage,
        processedImage,
        setProcessedImage,
        isProcessing,
        setIsProcessing,
        adjustments,
        setAdjustments,
        size,
        setSize,
        exportSettings,
        setExportSettings,
        resetAll,
      }}
    >
      {children}
    </ImageContext.Provider>
  );
}

export function useImageContext() {
  const context = useContext(ImageContext);
  if (context === undefined) {
    throw new Error("useImageContext must be used within an ImageProvider");
  }
  return context;
}
