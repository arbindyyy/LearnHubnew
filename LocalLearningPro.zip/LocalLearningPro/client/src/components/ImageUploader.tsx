import { useRef, useState } from "react";
import { Upload } from "lucide-react";
import { useImageContext } from "@/context/ImageContext";

interface ImageUploaderProps {
  onImageUploaded: () => void;
}

export default function ImageUploader({ onImageUploaded }: ImageUploaderProps) {
  const { setOriginalImage, setProcessedImage, setSize } = useImageContext();
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        setOriginalImage(img);
        setProcessedImage(event.target?.result as string);
        
        // Update size state with the image's original dimensions
        setSize(prev => ({
          ...prev,
          width: img.width,
          height: img.height
        }));
        
        onImageUploaded();
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div 
      className={`drag-area rounded-xl flex flex-col items-center justify-center p-12 cursor-pointer ${isDragging ? 'active' : ''}`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={handleBrowseClick}
    >
      <Upload className="h-16 w-16 text-gray-400 mb-4" />
      <p className="text-gray-600 dark:text-gray-400 mb-2">Drag & drop your image here</p>
      <p className="text-gray-500 dark:text-gray-500 text-sm mb-4">or</p>
      <label 
        className="px-4 py-2 bg-primary hover:bg-primary/90 text-white rounded-lg transition-colors cursor-pointer"
      >
        Browse Files
      </label>
      <input 
        type="file" 
        id="file-input" 
        ref={fileInputRef}
        accept="image/*" 
        className="hidden" 
        onChange={handleFileInputChange}
      />
      <p className="text-gray-500 dark:text-gray-500 text-xs mt-4">Supported formats: JPG, PNG, WEBP</p>
    </div>
  );
}
