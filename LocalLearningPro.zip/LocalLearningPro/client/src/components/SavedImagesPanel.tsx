import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useImageContext } from "@/context/ImageContext";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Image as ImageIcon, Trash2, Clock, Save, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DatabaseImage {
  id: number;
  userId?: number;
  name: string;
  originalUrl: string;
  processedUrl?: string;
  fileSize?: number;
  width?: number;
  height?: number;
  format?: string;
  createdAt?: string;
  metadata?: any;
}

export default function SavedImagesPanel() {
  const { originalImage, processedImage, setOriginalImage, setProcessedImage, adjustments } = useImageContext();
  const [selectedImageId, setSelectedImageId] = useState<number | null>(null);

  // Query to fetch saved images
  const { data: images = [], isLoading, error } = useQuery<DatabaseImage[]>({
    queryKey: ['/api/images'],
    enabled: true
  });

  // Mutation to save a new image
  const saveImageMutation = useMutation({
    mutationFn: async (imageData: any) => {
      const res = await apiRequest('POST', '/api/images', imageData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/images'] });
    },
  });

  // Mutation to delete an image
  const deleteImageMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/images/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/images'] });
      setSelectedImageId(null);
    },
  });

  // Mutation to save edit history
  const saveHistoryMutation = useMutation({
    mutationFn: async ({ imageId, adjustments }: { imageId: number, adjustments: any }) => {
      const res = await apiRequest('POST', `/api/images/${imageId}/history`, { adjustments });
      return res.json();
    }
  });

  // Handle saving current image
  const handleSaveImage = async () => {
    if (!originalImage || !processedImage) return;
    
    try {
      // Create a name from date
      const name = `Image_${new Date().toISOString().split('T')[0]}_${Date.now().toString().slice(-6)}`;
      
      // Save image to database
      const imageData = {
        userId: 1, // In a real app, this would be the authenticated user's ID
        name,
        originalUrl: originalImage.src,
        processedUrl: processedImage,
        width: originalImage.width,
        height: originalImage.height,
        fileSize: Math.round(processedImage.length / 1.37), // Rough estimation of file size from base64
        format: processedImage.includes('data:image/png') ? 'png' : 
                processedImage.includes('data:image/webp') ? 'webp' : 'jpg',
        metadata: { browser: navigator.userAgent }
      };
      
      await saveImageMutation.mutateAsync(imageData);
    } catch (error) {
      console.error("Failed to save image:", error);
    }
  };

  // Handle loading a saved image
  const handleLoadImage = async (image: DatabaseImage) => {
    setSelectedImageId(image.id);
    
    try {
      // Load original image
      const originalImg = new globalThis.Image();
      originalImg.onload = () => {
        setOriginalImage(originalImg);
        
        // Load processed image if available
        if (image.processedUrl) {
          setProcessedImage(image.processedUrl);
        } else {
          setProcessedImage(image.originalUrl);
        }
      };
      originalImg.src = image.originalUrl;
    } catch (error) {
      console.error("Failed to load image:", error);
    }
  };

  // Handle saving edit history
  const handleSaveHistory = async () => {
    if (!selectedImageId) return;
    
    try {
      await saveHistoryMutation.mutateAsync({
        imageId: selectedImageId,
        adjustments: adjustments
      });
    } catch (error) {
      console.error("Failed to save edit history:", error);
    }
  };

  // Handle deleting an image
  const handleDeleteImage = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering the parent click handler
    
    if (confirm("Are you sure you want to delete this image?")) {
      await deleteImageMutation.mutateAsync(id);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-4 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">Saved Images</h3>
        {originalImage && processedImage && (
          <Button 
            onClick={handleSaveImage}
            variant="outline"
            size="sm"
            className="flex items-center gap-1"
            disabled={saveImageMutation.isPending}
          >
            <Save className="h-4 w-4" />
            {saveImageMutation.isPending ? 'Saving...' : 'Save Current'}
          </Button>
        )}
      </div>
      
      {selectedImageId && (
        <div className="mb-4 flex justify-end">
          <Button
            onClick={handleSaveHistory}
            variant="outline"
            size="sm"
            className="flex items-center gap-1"
            disabled={saveHistoryMutation.isPending}
          >
            <Clock className="h-4 w-4" />
            Save Current State
          </Button>
        </div>
      )}
      
      {isLoading ? (
        <div className="py-4 text-center text-gray-500">Loading saved images...</div>
      ) : error ? (
        <div className="py-4 text-center text-red-500">Failed to load images</div>
      ) : images && images.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {images.map((image: DatabaseImage) => (
            <div 
              key={image.id}
              onClick={() => handleLoadImage(image)}
              className={`border rounded-lg p-2 cursor-pointer hover:border-primary transition-colors ${
                selectedImageId === image.id ? 'border-primary bg-primary/5' : ''
              }`}
            >
              <div className="aspect-square bg-gray-100 dark:bg-gray-800 rounded-md mb-2 overflow-hidden">
                {image.processedUrl ? (
                  <img 
                    src={image.processedUrl} 
                    alt={image.name}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <ImageIcon className="h-10 w-10 text-gray-400" />
                  </div>
                )}
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm truncate" title={image.name}>
                  {image.name}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 text-gray-500 hover:text-red-500"
                  onClick={(e) => handleDeleteImage(image.id, e)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-4 text-center text-gray-500">
          No saved images yet. Edit an image and click "Save Current" to store it.
        </div>
      )}
    </div>
  );
}