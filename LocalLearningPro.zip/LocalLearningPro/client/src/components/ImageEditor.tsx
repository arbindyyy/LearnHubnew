import { useState } from "react";
import ImageUploader from "./ImageUploader";
import ToolPanel from "./ToolPanel";
import PreviewPanel from "./PreviewPanel";

export default function ImageEditor() {
  const [showEditor, setShowEditor] = useState(false);

  const handleImageUploaded = () => {
    setShowEditor(true);
  };

  return (
    <section className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-6 mb-12 animate-fade-in">
      <h2 className="text-2xl font-bold mb-6 text-center">Start Editing Your Image</h2>
      
      {/* Image Uploader - shown when no image is uploaded */}
      {!showEditor && (
        <div className="mb-8" id="image-uploader">
          <ImageUploader onImageUploaded={handleImageUploaded} />
        </div>
      )}
      
      {/* Editor Workspace - shown after image is uploaded */}
      {showEditor && (
        <div id="editor-workspace" className="animate-slide-up">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <ToolPanel />
            <PreviewPanel />
          </div>
        </div>
      )}
    </section>
  );
}
