import React from "react";

interface ExampleCardProps {
  title: string;
  beforeImage: string;
  afterImage: string;
  beforeAlt: string;
  afterAlt: string;
}

export default function ExampleCard({ 
  title, 
  beforeImage, 
  afterImage, 
  beforeAlt, 
  afterAlt 
}: ExampleCardProps) {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg overflow-hidden">
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <h3 className="font-semibold">{title}</h3>
      </div>
      <div className="grid grid-cols-2 gap-4 p-4">
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Before</p>
          <img 
            src={beforeImage} 
            alt={beforeAlt} 
            className="w-full h-48 object-cover rounded-lg" 
          />
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">After</p>
          {title === "Background Removal" ? (
            <div className="w-full h-48 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
              <img 
                src={afterImage} 
                alt={afterAlt} 
                className="h-40 object-contain" 
              />
            </div>
          ) : (
            <img 
              src={afterImage} 
              alt={afterAlt} 
              className="w-full h-48 object-cover rounded-lg" 
            />
          )}
        </div>
      </div>
    </div>
  );
}
