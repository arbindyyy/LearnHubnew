import { useEffect, useRef, useState } from "react";

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
}

export default function BeforeAfterSlider({ beforeImage, afterImage }: BeforeAfterSliderProps) {
  const [position, setPosition] = useState(50);
  const sliderRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);

  useEffect(() => {
    const handleMouseDown = () => {
      isDraggingRef.current = true;
    };

    const handleMouseUp = () => {
      isDraggingRef.current = false;
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current || !sliderRef.current) return;
      
      const sliderRect = sliderRef.current.getBoundingClientRect();
      const newPosition = ((e.clientX - sliderRect.left) / sliderRect.width) * 100;
      setPosition(Math.max(0, Math.min(100, newPosition)));
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDraggingRef.current || !sliderRef.current) return;
      
      const sliderRect = sliderRef.current.getBoundingClientRect();
      const touch = e.touches[0];
      const newPosition = ((touch.clientX - sliderRect.left) / sliderRect.width) * 100;
      setPosition(Math.max(0, Math.min(100, newPosition)));
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('touchend', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleMouseUp);
    };
  }, []);

  return (
    <div 
      ref={sliderRef}
      className="compare-slider h-64 md:h-96 rounded-xl overflow-hidden shadow-xl mb-8 w-full"
    >
      <div 
        className="compare-slider-before"
        style={{ backgroundImage: `url(${beforeImage})` }}
      />
      <div 
        className="compare-slider-after"
        style={{ 
          backgroundImage: `url(${afterImage})`,
          width: `${position}%` 
        }}
      />
      <div 
        className="compare-slider-handle"
        style={{ left: `${position}%` }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleMouseDown}
      >
        <div className="flex justify-center items-center h-full">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-5 w-5 text-primary" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M8 7h8M8 12h8M8 17h8" 
            />
          </svg>
        </div>
      </div>
    </div>
  );

  function handleMouseDown() {
    isDraggingRef.current = true;
  }
}
