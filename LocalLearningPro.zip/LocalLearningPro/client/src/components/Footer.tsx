import React from "react";
import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-gray-100 dark:bg-gray-900 py-8 border-t border-gray-200 dark:border-gray-800 animate-fade-in">
      <div className="container mx-auto px-4 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">PixelPro</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Professional image editing tools, 100% free and accessible to everyone.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/"><a className="text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary">Home</a></Link></li>
              <li><a href="#tools" className="text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary">Tools</a></li>
              <li><a href="#examples" className="text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary">Examples</a></li>
              <li><a href="#faq" className="text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Get in Touch</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">
              Have questions or suggestions? We'd love to hear from you.
            </p>
            <a 
              href="mailto:contact@pixelpro.example.com" 
              className="inline-block px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
            >
              Contact Us
            </a>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-800 text-center text-sm text-gray-500 dark:text-gray-400">
          &copy; {new Date().getFullYear()} PixelPro. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
