import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";

interface ToolCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
}

export default function ToolCard({ title, description, icon: Icon }: ToolCardProps) {
  return (
    <div className="tool-card bg-white dark:bg-gray-900 rounded-xl shadow-md p-6 relative">
      <div className="free-badge">
        <Badge variant="secondary">100% Free</Badge>
      </div>
      <div className="mb-4 text-primary dark:text-primary">
        <Icon className="h-8 w-8" />
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 dark:text-gray-400 text-sm">
        {description}
      </p>
    </div>
  );
}
