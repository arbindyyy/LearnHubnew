import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useImageContext } from "@/context/ImageContext";
import { Clock, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

interface EditHistoryPanelProps {
  imageId: number | null;
}

interface HistoryAdjustments {
  brightness?: number;
  contrast?: number;
  saturation?: number;
  [key: string]: any;
}

interface HistoryItem {
  id: number;
  imageId: number;
  userId?: number;
  adjustments: HistoryAdjustments;
  createdAt: string;
}

export default function EditHistoryPanel({ imageId }: EditHistoryPanelProps) {
  const { setAdjustments } = useImageContext();
  
  // Query to fetch edit history for the current image
  const { data: history = [], isLoading, error } = useQuery({
    queryKey: [`/api/images/${imageId}/history`],
    enabled: !!imageId,
  });

  // Apply a historical state
  const applyHistoryState = (historyItem: HistoryItem) => {
    if (historyItem.adjustments) {
      // Create a proper adjustments object with all required properties
      setAdjustments({
        brightness: historyItem.adjustments.brightness ?? 0,
        contrast: historyItem.adjustments.contrast ?? 0,
        saturation: historyItem.adjustments.saturation ?? 0
      });
    }
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (error) {
      return "Unknown date";
    }
  };

  if (!imageId) {
    return null;
  }

  return (
    <div className="mt-4">
      <h4 className="text-md font-medium flex items-center gap-1 mb-3">
        <Clock className="h-4 w-4" />
        Edit History
      </h4>
      
      {isLoading ? (
        <div className="py-2 text-center text-gray-500 text-sm">Loading history...</div>
      ) : error ? (
        <div className="py-2 text-center text-red-500 text-sm">Failed to load history</div>
      ) : Array.isArray(history) && history.length > 0 ? (
        <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
          {history.map((item: HistoryItem) => (
            <div 
              key={item.id}
              className="border dark:border-gray-700 rounded p-2 hover:border-primary cursor-pointer transition-colors"
              onClick={() => applyHistoryState(item)}
            >
              <div className="flex justify-between items-center">
                <span className="text-xs text-gray-500">
                  {formatDate(item.createdAt)}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={(e) => {
                    e.stopPropagation();
                    applyHistoryState(item);
                  }}
                >
                  <RotateCcw className="h-3 w-3" />
                </Button>
              </div>
              
              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                {item.adjustments && typeof item.adjustments.brightness !== 'undefined' && (
                  <span className="inline-block mr-2">
                    Brightness: {item.adjustments.brightness}
                  </span>
                )}
                {item.adjustments && typeof item.adjustments.contrast !== 'undefined' && (
                  <span className="inline-block mr-2">
                    Contrast: {item.adjustments.contrast}
                  </span>
                )}
                {item.adjustments && typeof item.adjustments.saturation !== 'undefined' && (
                  <span className="inline-block">
                    Saturation: {item.adjustments.saturation}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-2 text-center text-gray-500 text-sm">
          No edit history available. Save changes to create history.
        </div>
      )}
    </div>
  );
}