import React, { useState, useEffect } from "react";
import { Slider } from "@/components/ui/slider";
import { useImageContext } from "@/context/ImageContext";
import { 
  RotateCw, 
  ArrowLeftRight, 
  ArrowUpDown, 
  Download,
  Scissors
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  processImage, 
  calculateAspectRatioDimensions, 
  removeBackground, 
  rotateImage, 
  flipImageHorizontal, 
  flipImageVertical 
} from "@/lib/imageProcessor";

interface AccordionItemProps {
  title: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
}

function AccordionItem({ title, defaultOpen = false, children }: AccordionItemProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
      <button 
        className="w-full px-4 py-3 text-left bg-gray-100 dark:bg-gray-700 font-medium flex justify-between items-center"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
      >
        <span>{title}</span>
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          className={`h-5 w-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} 
          fill="none" 
          viewBox="0 0 24 24" 
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      {isOpen && (
        <div className="p-4 space-y-4">
          {children}
        </div>
      )}
    </div>
  );
}

export default function ToolPanel() {
  const { 
    originalImage, 
    setProcessedImage,
    setIsProcessing,
    adjustments, 
    setAdjustments,
    size, 
    setSize,
    exportSettings, 
    setExportSettings,
    resetAll
  } = useImageContext();

  // Update processed image when adjustments change
  useEffect(() => {
    if (!originalImage) return;
    
    const applyChanges = async () => {
      setIsProcessing(true);
      try {
        // Calculate dimensions based on aspect ratio if needed
        let finalWidth = size.width;
        let finalHeight = size.height;
        
        if (size.maintainAspectRatio) {
          const dimensions = calculateAspectRatioDimensions(
            originalImage.naturalWidth,
            originalImage.naturalHeight,
            size.width,
            size.height,
            true
          );
          finalWidth = dimensions.width;
          finalHeight = dimensions.height;
        }
        
        const result = await processImage(originalImage, {
          width: finalWidth,
          height: finalHeight,
          brightness: adjustments.brightness,
          contrast: adjustments.contrast,
          saturation: adjustments.saturation,
          format: exportSettings.format,
          quality: exportSettings.quality
        });
        
        setProcessedImage(result);
      } catch (error) {
        console.error('Error processing image:', error);
      } finally {
        setIsProcessing(false);
      }
    };
    
    // Debounce the processing to avoid excessive rendering
    const timeoutId = setTimeout(applyChanges, 200);
    return () => clearTimeout(timeoutId);
  }, [originalImage, adjustments, size, exportSettings, setProcessedImage, setIsProcessing]);

  const handleWidthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newWidth = parseInt(e.target.value, 10) || 0;
    if (size.maintainAspectRatio && originalImage) {
      const aspectRatio = originalImage.naturalWidth / originalImage.naturalHeight;
      setSize({
        ...size,
        width: newWidth,
        height: Math.round(newWidth / aspectRatio)
      });
    } else {
      setSize({
        ...size,
        width: newWidth
      });
    }
  };

  const handleHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newHeight = parseInt(e.target.value, 10) || 0;
    if (size.maintainAspectRatio && originalImage) {
      const aspectRatio = originalImage.naturalWidth / originalImage.naturalHeight;
      setSize({
        ...size,
        height: newHeight,
        width: Math.round(newHeight * aspectRatio)
      });
    } else {
      setSize({
        ...size,
        height: newHeight
      });
    }
  };

  const handleRotate = async () => {
    if (!originalImage) return;
    
    setIsProcessing(true);
    try {
      const rotated = await rotateImage(originalImage, 90);
      setProcessedImage(rotated);
      
      // Create a new Image to get the rotated dimensions
      const img = new Image();
      img.onload = () => {
        setSize({
          ...size,
          width: img.width,
          height: img.height
        });
      };
      img.src = rotated;
    } catch (error) {
      console.error('Error rotating image:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFlipHorizontal = async () => {
    if (!originalImage) return;
    
    setIsProcessing(true);
    try {
      const flipped = await flipImageHorizontal(originalImage);
      setProcessedImage(flipped);
    } catch (error) {
      console.error('Error flipping image:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFlipVertical = async () => {
    if (!originalImage) return;
    
    setIsProcessing(true);
    try {
      const flipped = await flipImageVertical(originalImage);
      setProcessedImage(flipped);
    } catch (error) {
      console.error('Error flipping image:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRemoveBackground = async () => {
    if (!originalImage) return;
    
    setIsProcessing(true);
    try {
      const result = await removeBackground(originalImage);
      setProcessedImage(result);
      
      // Update export format to PNG to preserve transparency
      setExportSettings({
        ...exportSettings,
        format: 'png'
      });
    } catch (error) {
      console.error('Error removing background:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (!originalImage) return;
    
    // Create a temporary link element
    const link = document.createElement('a');
    
    // Use the processed image if available, otherwise use the original
    const imageToDownload = document.getElementById('preview-image') as HTMLImageElement;
    
    if (imageToDownload) {
      // Create a canvas to draw the image
      const canvas = document.createElement('canvas');
      canvas.width = imageToDownload.naturalWidth;
      canvas.height = imageToDownload.naturalHeight;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(imageToDownload, 0, 0);
        
        // Set download attributes
        link.download = `pixelpro-edited-image.${exportSettings.format}`;
        link.href = canvas.toDataURL(`image/${exportSettings.format}`, exportSettings.quality / 100);
        
        // Trigger download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  };

  return (
    <div className="lg:col-span-1 bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
      <h3 className="text-lg font-semibold mb-4">Tools</h3>
      
      <div className="space-y-4">
        <AccordionItem title="Basic Transforms" defaultOpen={true}>
          <div>
            <label className="block text-sm font-medium mb-1">Resize</label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-gray-500 dark:text-gray-400">Width (px)</label>
                <input 
                  type="number" 
                  className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm"
                  value={size.width}
                  onChange={handleWidthChange}
                  min={1}
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 dark:text-gray-400">Height (px)</label>
                <input 
                  type="number" 
                  className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm"
                  value={size.height}
                  onChange={handleHeightChange}
                  min={1}
                />
              </div>
            </div>
            <div className="mt-2">
              <label className="inline-flex items-center">
                <input 
                  type="checkbox" 
                  className="rounded border-gray-300 dark:border-gray-600 text-primary"
                  checked={size.maintainAspectRatio}
                  onChange={(e) => setSize({ ...size, maintainAspectRatio: e.target.checked })}
                />
                <span className="ml-2 text-sm">Maintain aspect ratio</span>
              </label>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Rotate & Flip</label>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="icon"
                onClick={handleRotate}
                disabled={!originalImage}
                className="p-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600"
              >
                <RotateCw className="h-5 w-5" />
              </Button>
              <Button 
                variant="outline" 
                size="icon"
                onClick={handleFlipHorizontal}
                disabled={!originalImage}
                className="p-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600"
              >
                <ArrowLeftRight className="h-5 w-5" />
              </Button>
              <Button 
                variant="outline" 
                size="icon"
                onClick={handleFlipVertical}
                disabled={!originalImage}
                className="p-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600"
              >
                <ArrowUpDown className="h-5 w-5" />
              </Button>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Crop</label>
            <Button 
              variant="default" 
              className="w-full py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors"
              disabled={!originalImage}
            >
              <Scissors className="h-4 w-4 mr-2" />
              Open Crop Tool
            </Button>
          </div>
        </AccordionItem>
        
        <AccordionItem title="Background Removal">
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
            Automatically remove the background from your image.
          </p>
          <Button 
            variant="secondary" 
            className="w-full py-2 bg-secondary text-white rounded-md hover:bg-secondary/90 transition-colors"
            onClick={handleRemoveBackground}
            disabled={!originalImage}
          >
            Remove Background
          </Button>
          <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
            Best for images with clear subjects and backgrounds
          </div>
        </AccordionItem>
        
        <AccordionItem title="Adjustments">
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-sm font-medium">Brightness</label>
              <span className="text-xs text-gray-500 dark:text-gray-400">{adjustments.brightness}</span>
            </div>
            <Slider 
              value={[adjustments.brightness]} 
              min={-100} 
              max={100} 
              step={1}
              onValueChange={(value) => setAdjustments({ ...adjustments, brightness: value[0] })}
            />
          </div>
          
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-sm font-medium">Contrast</label>
              <span className="text-xs text-gray-500 dark:text-gray-400">{adjustments.contrast}</span>
            </div>
            <Slider 
              value={[adjustments.contrast]} 
              min={-100} 
              max={100} 
              step={1}
              onValueChange={(value) => setAdjustments({ ...adjustments, contrast: value[0] })}
            />
          </div>
          
          <div>
            <div className="flex justify-between mb-1">
              <label className="text-sm font-medium">Saturation</label>
              <span className="text-xs text-gray-500 dark:text-gray-400">{adjustments.saturation}</span>
            </div>
            <Slider 
              value={[adjustments.saturation]} 
              min={-100} 
              max={100} 
              step={1}
              onValueChange={(value) => setAdjustments({ ...adjustments, saturation: value[0] })}
            />
          </div>
        </AccordionItem>
        
        <AccordionItem title="Export">
          <div>
            <label className="block text-sm font-medium mb-1">Format</label>
            <select 
              className="w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm"
              value={exportSettings.format}
              onChange={(e) => setExportSettings({ ...exportSettings, format: e.target.value as "jpg" | "png" | "webp" })}
            >
              <option value="jpg">JPG</option>
              <option value="png">PNG</option>
              <option value="webp">WEBP</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Quality</label>
            <div className="flex justify-between mb-1">
              <span className="text-xs text-gray-500 dark:text-gray-400">Low</span>
              <span className="text-xs text-gray-500 dark:text-gray-400">High</span>
            </div>
            <Slider 
              value={[exportSettings.quality]} 
              min={0} 
              max={100} 
              step={1}
              onValueChange={(value) => setExportSettings({ ...exportSettings, quality: value[0] })}
            />
          </div>
          
          <Button 
            variant="default" 
            className="w-full py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors flex items-center justify-center"
            onClick={handleDownload}
            disabled={!originalImage}
          >
            <Download className="h-5 w-5 mr-1" />
            Download Image
          </Button>
        </AccordionItem>
      </div>
    </div>
  );
}
