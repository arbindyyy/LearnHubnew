import React from "react";

interface FAQItemProps {
  question: string;
  answer: string;
  isLast?: boolean;
}

function FAQItem({ question, answer, isLast = false }: FAQItemProps) {
  return (
    <div className={`${isLast ? '' : 'border-b border-gray-200 dark:border-gray-800 pb-4'}`}>
      <h3 className="text-xl font-semibold mb-2">{question}</h3>
      <p className="text-gray-600 dark:text-gray-400">
        {answer}
      </p>
    </div>
  );
}

export default function FAQ() {
  const faqItems = [
    {
      question: "Is PixelPro really 100% free?",
      answer: "Yes! All editing tools are completely free to use with no hidden fees or watermarks."
    },
    {
      question: "Do I need to create an account?",
      answer: "No account is required. Simply upload your image and start editing right away."
    },
    {
      question: "Is my data secure?",
      answer: "All image processing happens directly in your browser. Your images are never uploaded to our servers."
    },
    {
      question: "What image formats are supported?",
      answer: "We support common image formats including JPG, PNG, and WEBP. You can also convert between these formats."
    }
  ];

  return (
    <section className="mb-16 animate-fade-in">
      <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
      
      <div className="max-w-3xl mx-auto bg-white dark:bg-gray-900 rounded-xl shadow-lg p-6">
        <div className="space-y-4">
          {faqItems.map((item, index) => (
            <FAQItem 
              key={index}
              question={item.question}
              answer={item.answer}
              isLast={index === faqItems.length - 1}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
