import { useTheme } from "@/context/ThemeContext";
import { Sun, Moon } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Header() {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="w-full py-4 px-6 md:px-12 flex items-center justify-between border-b border-gray-200 dark:border-gray-800 animate-fade-in">
      <div className="flex items-center">
        <div className="text-primary dark:text-primary text-3xl font-bold">PixelPro</div>
        <Badge variant="secondary" className="ml-2">100% Free</Badge>
      </div>
      
      <button 
        onClick={toggleTheme}
        className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
        aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      >
        {theme === 'dark' ? (
          <Sun className="h-6 w-6 text-gray-200" />
        ) : (
          <Moon className="h-6 w-6 text-gray-800" />
        )}
      </button>
    </header>
  );
}
