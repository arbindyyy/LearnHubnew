// Theme constants and utilities

// Define the theme type
export type Theme = "light" | "dark";

// Local storage key for theme preference
export const THEME_STORAGE_KEY = "pixelpro-theme";

// Check system preference for dark mode
export function getSystemPreference(): Theme {
  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
}

// Get theme from local storage or use system preference as fallback
export function getSavedTheme(): Theme {
  const savedTheme = localStorage.getItem(THEME_STORAGE_KEY) as Theme | null;
  return savedTheme || getSystemPreference();
}

// Save theme preference to local storage
export function saveTheme(theme: Theme): void {
  localStorage.setItem(THEME_STORAGE_KEY, theme);
}

// Apply theme to document element
export function applyTheme(theme: Theme): void {
  if (theme === "dark") {
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
  }
}

// Toggle between light and dark themes
export function toggleTheme(currentTheme: Theme): Theme {
  const newTheme = currentTheme === "light" ? "dark" : "light";
  saveTheme(newTheme);
  applyTheme(newTheme);
  return newTheme;
}

// Theme colors for reference
export const themeColors = {
  light: {
    primary: "hsl(207, 90%, 54%)",
    secondary: "hsl(142, 71%, 45%)",
    background: "hsl(0, 0%, 100%)",
    foreground: "hsl(20, 14.3%, 4.1%)",
    muted: "hsl(60, 4.8%, 95.9%)",
    card: "hsl(0, 0%, 100%)",
  },
  dark: {
    primary: "hsl(207, 90%, 54%)",
    secondary: "hsl(142, 71%, 45%)",
    background: "hsl(240, 10%, 3.9%)",
    foreground: "hsl(0, 0%, 98%)",
    muted: "hsl(240, 3.7%, 15.9%)",
    card: "hsl(240, 10%, 3.9%)",
  },
};

// Add event listener for system preference changes
export function listenForSystemPreferenceChanges(callback: (theme: Theme) => void): () => void {
  const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
  
  const handleChange = (e: MediaQueryListEvent) => {
    const newTheme = e.matches ? "dark" : "light";
    callback(newTheme);
  };
  
  // Add event listener
  if (mediaQuery.addEventListener) {
    mediaQuery.addEventListener("change", handleChange);
  } else {
    // For older browsers
    mediaQuery.addListener(handleChange);
  }
  
  // Return cleanup function
  return () => {
    if (mediaQuery.removeEventListener) {
      mediaQuery.removeEventListener("change", handleChange);
    } else {
      // For older browsers
      mediaQuery.removeListener(handleChange);
    }
  };
}
