export interface ProcessOptions {
  width: number;
  height: number;
  brightness: number;
  contrast: number;
  saturation: number;
  format: string;
  quality: number;
}

// Helper function to create a canvas element
function createCanvas(width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

// Process image with the provided options
export async function processImage(image: HTMLImageElement, options: ProcessOptions): Promise<string> {
  // Create canvas with the target dimensions
  const canvas = createCanvas(options.width, options.height);
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }

  // Draw the image on the canvas with resizing
  ctx.drawImage(image, 0, 0, options.width, options.height);
  
  // Apply image adjustments
  if (options.brightness !== 0 || options.contrast !== 0 || options.saturation !== 0) {
    applyAdjustments(canvas, options);
  }
  
  // Return the processed image as data URL
  return canvas.toDataURL(`image/${options.format}`, options.quality / 100);
}

// Apply brightness, contrast, and saturation adjustments
function applyAdjustments(canvas: HTMLCanvasElement, options: ProcessOptions): void {
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    return;
  }
  
  // Get image data
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  
  // Normalize adjustment values
  const brightness = options.brightness / 100;
  const contrast = options.contrast / 100;
  const saturation = options.saturation / 100;
  
  for (let i = 0; i < data.length; i += 4) {
    // Get RGB values
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];
    
    // Apply brightness
    if (brightness !== 0) {
      r += 255 * brightness;
      g += 255 * brightness;
      b += 255 * brightness;
    }
    
    // Apply contrast
    if (contrast !== 0) {
      const factor = (259 * (contrast + 1)) / (255 * (1 - contrast));
      r = factor * (r - 128) + 128;
      g = factor * (g - 128) + 128;
      b = factor * (b - 128) + 128;
    }
    
    // Apply saturation
    if (saturation !== 0) {
      const gray = 0.2989 * r + 0.587 * g + 0.114 * b;
      r = r + saturation * (r - gray);
      g = g + saturation * (g - gray);
      b = b + saturation * (b - gray);
    }
    
    // Clamp values to valid range
    data[i] = Math.max(0, Math.min(255, r));
    data[i + 1] = Math.max(0, Math.min(255, g));
    data[i + 2] = Math.max(0, Math.min(255, b));
  }
  
  // Put the modified image data back
  ctx.putImageData(imageData, 0, 0);
}

// Resize image while maintaining aspect ratio
export function calculateAspectRatioDimensions(
  originalWidth: number,
  originalHeight: number,
  targetWidth: number,
  targetHeight: number,
  maintainAspectRatio: boolean
): { width: number; height: number } {
  if (!maintainAspectRatio) {
    return { width: targetWidth, height: targetHeight };
  }
  
  const aspectRatio = originalWidth / originalHeight;
  let width = targetWidth;
  let height = targetHeight;
  
  if (targetWidth / targetHeight > aspectRatio) {
    width = Math.round(targetHeight * aspectRatio);
  } else {
    height = Math.round(targetWidth / aspectRatio);
  }
  
  return { width, height };
}

// Remove background (simplified version)
export async function removeBackground(image: HTMLImageElement): Promise<string> {
  const canvas = createCanvas(image.width, image.height);
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }
  
  // Draw the image
  ctx.drawImage(image, 0, 0);
  
  // Get image data
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  
  // This is a very simplified background removal that assumes
  // the corners of the image represent the background color
  const cornerColors = [
    getPixelColor(data, 0, 0, canvas.width),
    getPixelColor(data, canvas.width - 1, 0, canvas.width),
    getPixelColor(data, 0, canvas.height - 1, canvas.width),
    getPixelColor(data, canvas.width - 1, canvas.height - 1, canvas.width),
  ];
  
  // Calculate average background color
  const avgBackground = {
    r: cornerColors.reduce((sum, color) => sum + color.r, 0) / 4,
    g: cornerColors.reduce((sum, color) => sum + color.g, 0) / 4,
    b: cornerColors.reduce((sum, color) => sum + color.b, 0) / 4,
  };
  
  // Threshold for considering a pixel as background
  const threshold = 30;
  
  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const idx = (y * canvas.width + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      
      // Calculate color distance
      const colorDistance = Math.sqrt(
        Math.pow(r - avgBackground.r, 2) +
        Math.pow(g - avgBackground.g, 2) +
        Math.pow(b - avgBackground.b, 2)
      );
      
      // If the color is close to background color, make it transparent
      if (colorDistance < threshold) {
        data[idx + 3] = 0; // Set alpha to 0 (transparent)
      }
    }
  }
  
  // Put the modified image data back
  ctx.putImageData(imageData, 0, 0);
  
  // Return as PNG (to preserve transparency)
  return canvas.toDataURL('image/png');
}

// Helper function to get pixel color
function getPixelColor(data: Uint8ClampedArray, x: number, y: number, width: number) {
  const idx = (y * width + x) * 4;
  return {
    r: data[idx],
    g: data[idx + 1],
    b: data[idx + 2],
  };
}

// Rotate image
export function rotateImage(image: HTMLImageElement, degrees: number): Promise<string> {
  return new Promise((resolve) => {
    // Create a canvas that will fit the rotated image
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      throw new Error('Failed to get canvas context');
    }
    
    // Convert degrees to radians
    const radians = (degrees * Math.PI) / 180;
    
    // Calculate new dimensions
    const sin = Math.abs(Math.sin(radians));
    const cos = Math.abs(Math.cos(radians));
    const newWidth = Math.round(image.width * cos + image.height * sin);
    const newHeight = Math.round(image.width * sin + image.height * cos);
    
    canvas.width = newWidth;
    canvas.height = newHeight;
    
    // Move to center of canvas
    ctx.translate(newWidth / 2, newHeight / 2);
    
    // Rotate
    ctx.rotate(radians);
    
    // Draw the image, centered
    ctx.drawImage(image, -image.width / 2, -image.height / 2);
    
    resolve(canvas.toDataURL());
  });
}

// Flip image horizontally
export function flipImageHorizontal(image: HTMLImageElement): Promise<string> {
  const canvas = createCanvas(image.width, image.height);
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }
  
  // Flip context horizontally
  ctx.translate(image.width, 0);
  ctx.scale(-1, 1);
  
  // Draw the image
  ctx.drawImage(image, 0, 0);
  
  return Promise.resolve(canvas.toDataURL());
}

// Flip image vertically
export function flipImageVertical(image: HTMLImageElement): Promise<string> {
  const canvas = createCanvas(image.width, image.height);
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }
  
  // Flip context vertically
  ctx.translate(0, image.height);
  ctx.scale(1, -1);
  
  // Draw the image
  ctx.drawImage(image, 0, 0);
  
  return Promise.resolve(canvas.toDataURL());
}
