import { 
  users, type User, type InsertUser,
  images, type Image, type InsertImage,
  editHistory, type EditHistory, type InsertEditHistory
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Storage interface with expanded functionality for images and edit history
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Image methods
  getImage(id: number): Promise<Image | undefined>;
  getUserImages(userId: number): Promise<Image[]>;
  createImage(image: InsertImage): Promise<Image>;
  updateImage(id: number, data: Partial<InsertImage>): Promise<Image | undefined>;
  deleteImage(id: number): Promise<boolean>;
  
  // Edit history methods
  getEditHistory(imageId: number): Promise<EditHistory[]>;
  createEditHistory(history: InsertEditHistory): Promise<EditHistory>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Image methods
  async getImage(id: number): Promise<Image | undefined> {
    const [image] = await db.select().from(images).where(eq(images.id, id));
    return image;
  }
  
  async getUserImages(userId: number): Promise<Image[]> {
    return await db.select().from(images).where(eq(images.userId, userId));
  }
  
  async createImage(image: InsertImage): Promise<Image> {
    const [newImage] = await db.insert(images).values(image).returning();
    return newImage;
  }
  
  async updateImage(id: number, data: Partial<InsertImage>): Promise<Image | undefined> {
    const [updatedImage] = await db
      .update(images)
      .set(data)
      .where(eq(images.id, id))
      .returning();
    return updatedImage;
  }
  
  async deleteImage(id: number): Promise<boolean> {
    const result = await db
      .delete(images)
      .where(eq(images.id, id))
      .returning({ id: images.id });
    return result.length > 0;
  }
  
  // Edit history methods
  async getEditHistory(imageId: number): Promise<EditHistory[]> {
    return await db
      .select()
      .from(editHistory)
      .where(eq(editHistory.imageId, imageId))
      .orderBy(editHistory.createdAt);
  }
  
  async createEditHistory(history: InsertEditHistory): Promise<EditHistory> {
    const [newHistory] = await db.insert(editHistory).values(history).returning();
    return newHistory;
  }
}

export const storage = new DatabaseStorage();
