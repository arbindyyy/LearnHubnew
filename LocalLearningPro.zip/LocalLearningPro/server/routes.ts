import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertImageSchema, insertEditHistorySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get user's images
  app.get("/api/images", async (req: Request, res: Response) => {
    try {
      // In a real app, you would get the user ID from the authenticated session
      // For demo purposes, we'll use a default user ID or from query params
      const userId = parseInt(req.query.userId as string) || 1;
      
      const images = await storage.getUserImages(userId);
      res.json(images);
    } catch (error) {
      console.error("Error fetching images:", error);
      res.status(500).json({ error: "Failed to fetch images" });
    }
  });

  // Get a specific image
  app.get("/api/images/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const image = await storage.getImage(id);
      
      if (!image) {
        return res.status(404).json({ error: "Image not found" });
      }
      
      res.json(image);
    } catch (error) {
      console.error("Error fetching image:", error);
      res.status(500).json({ error: "Failed to fetch image" });
    }
  });

  // Save a new image
  app.post("/api/images", async (req: Request, res: Response) => {
    try {
      // Validate request body
      const result = insertImageSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ error: "Invalid image data", details: result.error });
      }
      
      const newImage = await storage.createImage(result.data);
      res.status(201).json(newImage);
    } catch (error) {
      console.error("Error saving image:", error);
      res.status(500).json({ error: "Failed to save image" });
    }
  });

  // Update an existing image
  app.patch("/api/images/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      // Get the existing image to make sure it exists
      const existingImage = await storage.getImage(id);
      if (!existingImage) {
        return res.status(404).json({ error: "Image not found" });
      }
      
      // Update the image
      const updatedImage = await storage.updateImage(id, req.body);
      res.json(updatedImage);
    } catch (error) {
      console.error("Error updating image:", error);
      res.status(500).json({ error: "Failed to update image" });
    }
  });

  // Delete an image
  app.delete("/api/images/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteImage(id);
      
      if (!success) {
        return res.status(404).json({ error: "Image not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting image:", error);
      res.status(500).json({ error: "Failed to delete image" });
    }
  });

  // Get edit history for an image
  app.get("/api/images/:id/history", async (req: Request, res: Response) => {
    try {
      const imageId = parseInt(req.params.id);
      const history = await storage.getEditHistory(imageId);
      res.json(history);
    } catch (error) {
      console.error("Error fetching edit history:", error);
      res.status(500).json({ error: "Failed to fetch edit history" });
    }
  });

  // Save edit history for an image
  app.post("/api/images/:id/history", async (req: Request, res: Response) => {
    try {
      const imageId = parseInt(req.params.id);
      
      // Check if the image exists
      const image = await storage.getImage(imageId);
      if (!image) {
        return res.status(404).json({ error: "Image not found" });
      }
      
      // Prepare the history entry
      const historyData = {
        imageId,
        userId: req.body.userId || image.userId, // Use the image's user ID as a fallback
        adjustments: req.body.adjustments
      };
      
      // Validate
      const result = insertEditHistorySchema.safeParse(historyData);
      if (!result.success) {
        return res.status(400).json({ error: "Invalid history data", details: result.error });
      }
      
      // Save the history entry
      const newHistory = await storage.createEditHistory(result.data);
      res.status(201).json(newHistory);
    } catch (error) {
      console.error("Error saving edit history:", error);
      res.status(500).json({ error: "Failed to save edit history" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
