import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const images = pgTable("images", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  originalUrl: text("original_url").notNull(),
  processedUrl: text("processed_url"),
  fileSize: integer("file_size"),
  width: integer("width"),
  height: integer("height"),
  format: text("format"),
  createdAt: timestamp("created_at").defaultNow(),
  metadata: jsonb("metadata")
});

export const editHistory = pgTable("edit_history", {
  id: serial("id").primaryKey(),
  imageId: integer("image_id").references(() => images.id).notNull(),
  userId: integer("user_id").references(() => users.id),
  adjustments: jsonb("adjustments").notNull(),
  createdAt: timestamp("created_at").defaultNow()
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertImageSchema = createInsertSchema(images).pick({
  userId: true,
  name: true,
  originalUrl: true,
  processedUrl: true,
  fileSize: true,
  width: true,
  height: true,
  format: true,
  metadata: true,
});

export const insertEditHistorySchema = createInsertSchema(editHistory).pick({
  imageId: true,
  userId: true,
  adjustments: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertImage = z.infer<typeof insertImageSchema>;
export type Image = typeof images.$inferSelect;

export type InsertEditHistory = z.infer<typeof insertEditHistorySchema>;
export type EditHistory = typeof editHistory.$inferSelect;
